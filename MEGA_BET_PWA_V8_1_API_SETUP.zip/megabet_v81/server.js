'use strict';
// MEGA BET secure API-Football proxy. Keep API_FOOTBALL_KEY on the server only.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');
const ROOT = __dirname;
// Load a local .env file without exposing secrets to the browser. Host environment variables take precedence.
try { const envFile = fs.readFileSync(path.join(ROOT, '.env'), 'utf8'); for (const line of envFile.split(/\r?\n/)) { const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/); if (m && !Object.prototype.hasOwnProperty.call(process.env, m[1])) process.env[m[1]] = m[2].replace(/^['\"]|['\"]$/g, ''); } } catch {}
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.API_FOOTBALL_KEY || '';
const cache = new Map();
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.txt':'text/plain; charset=utf-8','.png':'image/png','.svg':'image/svg+xml'};
function send(res, status, body, type='application/json; charset=utf-8') { res.writeHead(status, {'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'}); res.end(typeof body === 'string' ? body : JSON.stringify(body)); }
function apiRequest(url) { return new Promise((resolve,reject)=>{ const req=https.get(url,{headers:{'x-apisports-key':API_KEY,'accept':'application/json'},timeout:15000},r=>{let data='';r.setEncoding('utf8');r.on('data',c=>data+=c);r.on('end',()=>{try{resolve({status:r.statusCode,body:JSON.parse(data)});}catch(e){reject(new Error('Invalid JSON received from API-Football'));}});});req.on('timeout',()=>req.destroy(new Error('Provider timeout')));req.on('error',reject);}); }
const allowedLeagues = new Set(['39','140','78','135','61','2','253']);
const validDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s+'T00:00:00Z'));
const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://localhost');
  if(u.pathname==='/api/health') return send(res,200,{ok:true,provider:'API-Football',configured:Boolean(API_KEY),message:API_KEY?'API key configured on server':'API key not configured. Set API_FOOTBALL_KEY on the server.'});
  if(u.pathname==='/api/verify'){
    if(!API_KEY) return send(res,503,{ok:false,configured:false,error:'API key is not configured on the server.'});
    const today=new Date().toISOString().slice(0,10);
    try { const result=await apiRequest('https://v3.football.api-sports.io/fixtures?league=39&season='+today.slice(0,4)+'&date='+today);
      if(result.status<200||result.status>=300) return send(res,502,{ok:false,configured:true,error:'Provider rejected the request.',providerStatus:result.status,details:result.body?.errors||null});
      if(result.body?.errors && Object.keys(result.body.errors).length) return send(res,502,{ok:false,configured:true,error:'API-Football returned an error.',details:result.body.errors});
      return send(res,200,{ok:true,configured:true,provider:'API-Football',testedDate:today,fixtureCount:(result.body?.response||[]).length,message:'API-Football request succeeded.'});
    } catch(e){return send(res,502,{ok:false,configured:true,error:'Could not reach API-Football.',details:e.message});}
  }
  if(u.pathname==='/api/fixtures'){
    if(!API_KEY) return send(res,503,{error:'API_FOOTBALL_KEY is not configured on the server. No demo data has been substituted.'});
    const league=u.searchParams.get('league')||'', season=u.searchParams.get('season')||'', date=u.searchParams.get('date'), from=u.searchParams.get('from'), to=u.searchParams.get('to');
    if(!allowedLeagues.has(league)) return send(res,400,{error:'Unsupported league id.'});
    if(!/^20\d{2}$/.test(season)) return send(res,400,{error:'A valid season year is required.'});
    if(date && !validDate(date)) return send(res,400,{error:'Invalid date. Use YYYY-MM-DD.'});
    if((from||to) && (!validDate(from)||!validDate(to)||from>to)) return send(res,400,{error:'Invalid date range.'});
    if(Boolean(date)===Boolean(from||to)) return send(res,400,{error:'Provide either date or both from and to.'});
    const params=new URLSearchParams({league,season}); if(date)params.set('date',date);else{params.set('from',from);params.set('to',to);}
    const key=params.toString(), cached=cache.get(key); if(cached&&cached.until>Date.now()) return send(res,200,cached.body);
    try { const result=await apiRequest('https://v3.football.api-sports.io/fixtures?'+key); if(result.status<200||result.status>=300) return send(res,502,{error:'API-Football request failed.',providerStatus:result.status,details:result.body?.errors||null}); if(result.body?.errors && Object.keys(result.body.errors).length) return send(res,502,{error:'API-Football returned an error.',details:result.body.errors}); cache.set(key,{body:result.body,until:Date.now()+(date?5:60)*60*1000}); return send(res,200,result.body); }
    catch(e){return send(res,502,{error:'Could not reach API-Football.',details:e.message});}
  }
  if(req.method!=='GET'&&req.method!=='HEAD') return send(res,405,{error:'Method not allowed.'});
  let pathname=decodeURIComponent(u.pathname); if(pathname==='/')pathname='/index.html'; const file=path.resolve(ROOT,'.'+pathname); if(!file.startsWith(ROOT+path.sep))return send(res,403,{error:'Forbidden'});
  fs.readFile(file,(err,buf)=>{if(err)return send(res,404,'Not found','text/plain; charset=utf-8');res.writeHead(200,{'content-type':MIME[path.extname(file)]||'application/octet-stream','x-content-type-options':'nosniff'});if(req.method==='HEAD')return res.end();res.end(buf);});
});
server.listen(PORT,()=>console.log(`MEGA BET listening on http://localhost:${PORT} | API key ${API_KEY?'configured':'NOT configured'}`));
