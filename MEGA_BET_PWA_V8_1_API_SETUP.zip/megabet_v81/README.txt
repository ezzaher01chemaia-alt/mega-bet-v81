MEGA BET V8.1 — API-Football server proxy package

WHAT IS INCLUDED
- Football fixtures API proxy (server-side only; API key never reaches the browser).
- /api/health reports whether a key is configured.
- /api/verify tests the provider with one fixtures request (Premier League, today) and reports count/date.
- /api/fixtures fetches real fixtures when configured.
- No demo fixtures are substituted on API failure.

SET UP LOCALLY (Node.js 18+)
1. Extract this ZIP.
2. Copy .env.example to a new file named .env.
3. Open .env and set API_FOOTBALL_KEY=YOUR_ROTATED_KEY. Do not send the key in chat.
4. Run npm start (or node server.js).
5. Open http://localhost:3000 and go to Settings > Test real API connection.
6. If verified, go Home, select date/league and press Fetch fixtures.

DEPLOYMENT
- Use a Node-capable host with HTTPS, not static-only hosting.
- Add API_FOOTBALL_KEY as a private environment/secret variable in hosting settings.
- Never upload the .env file; it is ignored by .gitignore.
- After changing the secret, restart/redeploy the service.

NOTES
- Provider quota is limited by the API-Football plan. Verification consumes one request.
- This prototype has no trained AI model; estimates are statistical, not guarantees.
- Demo screens remain demo-only and performance stats require recorded outcomes.

QUICK DEPLOY (Render-style Node Web Service)
1. Upload/import this project folder to a Git repository (exclude .env).
2. On your host, create a new Node Web Service from that repository.
3. Build command: npm install
4. Start command: npm start
5. In the host's Environment/Secrets settings, add API_FOOTBALL_KEY with your newly rotated key. Never paste it into the source code, app UI, or chat.
6. Deploy/restart, then open /api/health. It should show configured:true (this only confirms the secret exists).
7. In MEGA BET Settings, tap Test real API connection. A successful verification confirms a provider request worked; it consumes one API request.
8. If verification fails, check the host logs and the API-Football dashboard/quota. Do not use a key that appeared in a screenshot; rotate it.

Deployment is not completed by this ZIP alone. The user must create/authorize the hosting account and add the private environment variable.
